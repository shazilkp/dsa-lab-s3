
	int preorderIndex = 0;
	for(int i = 0 ; i < n ; i++){
		scanf("%d",&inorder[i]);
	}
	
	for(int i = 0 ; i < n ; i++){
		scanf("%d",&preorder[i]);