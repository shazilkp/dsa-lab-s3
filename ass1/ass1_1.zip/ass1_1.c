#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct bt{
	int data;
	struct bt* left;
	struct bt* right;
};

typedef struct bt node;

struct linkedlist{
	node * currNode;
	struct linkedlist* next;
	struct linkedlist* prev;
};

typedef struct linkedlist llnode; 

llnode * createQueueNode(node * currNode){
	llnode * x = (llnode *)malloc(sizeof(llnode));
	x->currNode = currNode;
	x->next = NULL;
	x->prev = NULL;
	return x;
}

void enqueueBack(llnode **head,llnode ** tail, node * currNode){
	llnode * node = createQueueNode(currNode);
	if(*tail && *head){
		(*tail)->next = node;
		node->prev = *tail;
		*tail = (*tail)->next;
		//printf("%d ",(*tail)->currNode->data);
	}
	else{
		*head = *tail = node; 
	}
}

void enqueueFront(llnode **head,llnode ** tail, node * currNode){
	llnode * node = createQueueNode(currNode);
	if(*tail && *head){
		node->next = *head;
		(*head)->prev = node;
		*head = (*head)->prev; 
		//printf("%d ",(*tail)->currNode->data);
	}
	else{
		*head = *tail = node; 
	}
}

node * dequeueFront(llnode ** head){
	if(*head){
		node * dequeuedElement = (*head)->currNode;
		llnode * oldHead = *head;
		*head = (*head)->next;
		(*head)->prev = NULL;
		free(oldHead);
		return dequeuedElement;
	}
	return NULL;
}

node * dequeueBack(llnode ** tail){
	if(*tail){
		node * dequeuedElement = (*tail)->currNode;
		llnode * oldtail = *tail;
		*tail = (*tail)->prev;
		(*tail)->next = NULL;
		free(oldtail);
		return dequeuedElement;
	}
	return NULL;
}

int queueSize(llnode * head){
	llnode * x = head;
	int count = 0;
	while(x){
		count++;
		x=x->next;
	}
	return count;
}


node * createNode(int data){
	node * x = (node *)malloc(sizeof(node));
	x->left = NULL;
	x->right = NULL;
	x->data = data;
	return x;
}

node * constructTree(int inorder[],int preorder[],int *preorderIndex, int inorderStart, int inorderEnd){
	if(inorderStart > inorderEnd){
		return NULL;								//no node
	}

	node * x = createNode(preorder[(*preorderIndex)++]);

	if(inorderStart == inorderEnd){					//no children
		return x;
	}

	int index;
	for(index = inorderStart ; index <= inorderEnd ; index++){			//find the index(in the inorder) of the element to be inserted
		if(x->data == inorder[index]){
			break;
		}
	}

	x->left = constructTree(inorder,preorder,preorderIndex,inorderStart,index-1);
	x->right = constructTree(inorder,preorder,preorderIndex,index+1,inorderEnd);

	return x;
}


void printqueue(llnode * head){
	llnode * x = head;
	while(x){
		printf("%d ",x->currNode->data);
		x=x->next;
	}
}



void levelOrder(node * root){
	int no_node_curr_level;
	llnode * head = createQueueNode(root);
	llnode * tail = head;
	node * current;
	int flag = 1;
	while(head){
		flag = !flag;
		no_node_curr_level = queueSize(head);
		//printf("Q_size = %d\n",no_node_curr_level);
		while(no_node_curr_level > 0){
			//printf("i = %d\n",no_node_curr_level);
			if(!flag){
				current = dequeueFront(&head);
				//printf("deq = %d \n",current->data);
				if(current->left){
					enqueueBack(&head,&tail,current->left);
				}
				if(current->right){
					enqueueBack(&head,&tail,current->right);
				}
				//printqueue(head);
				//printf("\n");
			}
			if(flag){
				current = dequeueBack(&tail);
				//printf("deq =%d \n",current->data);
				if(current->right){
					enqueueFront(&head,&tail,current->right);
				}
				if(current->left){
					enqueueFront(&head,&tail,current->left);
				}
				//printqueue(head);
				//printf("\n");
				
			}
			printqueue(head);
			printf("\n");
			no_node_curr_level--;
		}

	}
}

void PostOrder(node * root){
	if(root == NULL){
		return;
	}
	PostOrder(root->left);
	PostOrder(root->right);
	printf("%d ",root->data);
}


int maxDepth(node * root){
	if(root == NULL){
		return 0;
	}
	int right_depth = maxDepth(root->right);
	int left_depth = maxDepth(root->left);

	return (right_depth > left_depth ? right_depth : left_depth) + 1;		//largest of 2 + 1
}

void printLevelOdd(node * root, int level){		//print a level from left to right
	if(root == NULL){
		return;
	}

	if(level == 0){
		printf("%d ",root->data);
		return;
	}
	printLevelOdd(root->left,level-1);
	printLevelOdd(root->right,level-1);
}

void printLevelEven(node * root, int level){ 	//print a level from right to left
	if(root == NULL){
		return;
	}

	if(level == 0){
		printf("%d ",root->data);
		return;
	}
	printLevelEven(root->right,level-1);
	printLevelEven(root->left,level-1);
}

/*
void printLevel(node * root, int level,int even){
	if(root == NULL){
		return;
	}

	if(level == 0){
		printf("%d ",root->data);
		return;
	}
	if(even){
		printLevel(root->right,level-1,even);
		printLevel(root->left,level-1,even);
	}
	else{
		printLevel(root->left,level-1,even);
		printLevel(root->right,level-1,even);
	}
}

void ZIG_ZAG2(node * root){
	int depth = maxDepth(root);
	int even = 1;
	for(int i = 0; i < depth ; i++){
		printLevel(root,i,even);
		even = !even;
	}
}

*/
void ZIG_ZAG(node * root){
	int depth = maxDepth(root);
	for(int i = 0; i < depth ; i++){											//iterate through all levels
		i%2 == 0 ? printLevelEven(root,i) : printLevelOdd(root,i);				//check if level is odd or even and print in proper order
	}
}

void LevelMax_helper(node * root, int level,int * max){								//traverses to a level and print the max of level
	if(root == NULL){
		return;
	}

	if(level == 0){
		if(root->data  > *max){
			*max = root->data; 
		}
		return;
	}
	LevelMax_helper(root->right,level-1,max);
	LevelMax_helper(root->left,level-1,max);
}

void LevelMax(node * root){						//calls levelmax_helper for all levels
	int depth = maxDepth(root);
	for(int i = 0 ; i < depth ; i++){
		int max = -1;
		LevelMax_helper(root,i,&max);
		printf("%d ",max);
	}
}


void RightLeafSum(node * root,node * parent, int * sum){

	if(root == NULL){				//base case
		return;
	}

	if(root->right == NULL && root->left == NULL){
		if(parent->right == root){						//if right leaf add to sum
			*sum = *sum + root->data;
		}
	}

	RightLeafSum(root->left,root,sum);
	RightLeafSum(root->right,root,sum);

}

int Diameter(node * root){
	if(root == NULL){
		return 0;
	}
	int d_left = Diameter(root->left);
	int d_right = Diameter(root->right);

	int longestPathRoot = maxDepth(root->left) + maxDepth(root->right) + 1;			//longest path with the current node as root ie current subtree

	return d_left > d_right ? (d_left > longestPathRoot ? d_left : longestPathRoot) : (d_right > longestPathRoot ? d_right : longestPathRoot); //largest of the 3
}

node * insertRandom(node * root, int data){
    if(root == NULL){
        return createNode(data);
    }

    int l_or_r = rand() % 2;

    if(l_or_r == 0){
        root->left = insertRandom(root->left,data);
    }
    else{
        root->right = insertRandom(root->right,data);
    }

    return root;
}


node * generateRandomTree(int n,int arr[]){
    node * root = createNode(arr[0]);
    for(int i = 0; i < n-1; i++){
        insertRandom(root,arr[i+1]);
    }
    return root;
}

void drawtree(node * root,int n,char label){
	if(root == NULL){
		return;
	}
	for(int i = 0;i<n;i++){
		printf("    ");
	}
	printf("%d%c",root->data,label);
	printf("\n");
	printf("\n");
	drawtree(root->right,n+1,'R');
	drawtree(root->left,n+1,'L');
}

int main(){

	srand(time(NULL));
    #define M 12
    #define N 125

    int in, im;

    im = 0;
    int vektor[M];
    for (in = 0; in < N && im < M; in++) {
    int rn = N - in;
    int rm = M - im;
    if (rand() % rn < rm)    
        /* Take it */
        vektor[im++] = in + 1; /* +1 since your range begins from 1 */
    }

	node * root = generateRandomTree(M,vektor);

	drawtree(root,0,'H');
	/*
	llnode * head = createQueueNode(root);
	llnode * tail = head;

	enqueue(&head,&tail,root->left);
	enqueue(&head,&tail,root->right);
	printqueue(head);
	printf("\n");
	dequeue(&head);
	printqueue(head);
	*/
	levelOrder(root);




	/*

	int n;
	scanf("%d",&n);
	int inorder[n];
	int preorder[n];
	
	int preorderIndex = 0;
	for(int i = 0 ; i < n ; i++){
		scanf("%d",&inorder[i]);
	}
	
	for(int i = 0 ; i < n ; i++){
		scanf("%d",&preorder[i]);
	}

	node * root = constructTree(inorder,preorder,&preorderIndex,0,n-1);

	char c;
	while(1){
	scanf("%c",&c);
	if(c == 'e'){
		break;
	}
	switch(c){
		case 'p':{
				PostOrder(root);
				printf("\n");
				break;
				}
		case 'z':{
				ZIG_ZAG(root);
				printf("\n");
				break;
				}
		case 'm':{
				LevelMax(root);
				printf("\n");
				break;
				}
		case 'd':{
				int dia = Diameter(root);
				printf("%d\n",dia);
				break;
				}
		case 's':{
				int sum=0;
				RightLeafSum(root,NULL,&sum);
				printf("%d\n",sum);
				break;
				}
		default:break;
	}
	}
	
*/	
}
